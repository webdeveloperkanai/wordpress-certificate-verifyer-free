<?php // Plugin Functions
function add_certificate_ks($code, $name, $course, $hours, $dob, $award_date, $editid, $photo, $mother, $father, $study_center_name ){
	global $wpdb;
    if( is_numeric($editid) && $editid != '' ) {
        $result = $wpdb->update('certificate_ks', array(
            'certificate_code' => $code,
            'student_name' => $name,
            'course_name'  => $course,
            'course_hours' => $hours,
            'dob' => $dob,
            'award_date' => $award_date, 
            'photo' => $photo,
            'mother' => $mother,
            'father' => $father, 
            'study_center_name' => $study_center_name,
            ),
            array( 'id' => $editid )
        );
    } else {
        $result = $wpdb->insert('certificate_ks', array(
            'certificate_code' => $code,
            'student_name' => $name,
            'course_name'  => $course,
            'course_hours' => $hours,
            'dob' => $dob,
            'award_date' => $award_date, 
            'photo' => $photo,
            'mother' => $mother,
            'father' => $father, 
            'study_center_name' => $study_center_name
            )
        );
    }
    return $result;
}


function delete_certificate_ks($editid) {
    global $wpdb;
    $result = false;
    if( is_numeric($editid) && $editid != '' ) {
        $result = $wpdb->delete('certificate_ks', array( 'id' => $editid ));
    }
    return $result;
}